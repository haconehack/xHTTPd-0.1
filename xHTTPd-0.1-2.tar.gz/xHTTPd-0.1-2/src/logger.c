/*
 * xHTTPd daemon.
 * Copyright(c) x90 all rights reserved.
 * Email: x90cx90c1@gmail.com
*/

#include <main.h>

int set_logformat( int level )
{

}

int write_log( char *logdata )
{
	FILE *fp;

	fp = fopen(HTTPd.log_path, "a+");

	fprintf(fp, "%s\n", logdata);

	fclose(fp);
}

