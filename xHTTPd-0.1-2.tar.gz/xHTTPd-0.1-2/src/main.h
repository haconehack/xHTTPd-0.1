#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/socket.h>
#include <netinet/in.h>
#include <signal.h>
#include <pthread.h>
#include <sys/stat.h>

#define     PORT                80      // ���� ��Ʈ

#define     MAX_USER            1024    // �ִ� ������
#define     MAX_CLIENT_THREAD   50      // Ŭ���̾�Ʈ ������ (�̸� �����Ǿ ����)
#define     MAX_MASTER_THREAD   4       // �ִ� ������ ������(Ŭ���̾�Ʈ �����带 ����)

#define     MAX_USER_ARGV       12      // ������ �ִ� �Ķ��Ÿ �� ( URL )
#define     MAX_POST_VAR        12      // var=val&var1=val1&var2=val2 ...
#define     MAX_COOKIE          12      // Cookie: var1=val1; var2=val2 ...
#define     LOG_LEVEL_ALERT     0
#define     LOG_LEVEL_INFO      1

struct _HTTPd
{
    int             port;
    int             max_user;
    int             max_thread;
    int             sock_id;
    struct          sockaddr_in sock_fd;
    pthread_t       thread[ MAX_MASTER_THREAD ];
    pthread_attr_t  tattr[ MAX_MASTER_THREAD ];
    char            path[ 129 ];            // Prefix path.
    char            htdocs_path[ 129 ];     // Getting from /etc/xHTTPd.conf
    char	    log_path[ 129 ];	    // access_log path
    pthread_mutex_t lock;
} HTTPd, *pHTTPd;

struct _CLIENT
{
    int                 current_user;
    pthread_t           thread[ MAX_CLIENT_THREAD * MAX_MASTER_THREAD ];
    pthread_attr_t      tattr[ MAX_CLIENT_THREAD * MAX_MASTER_THREAD ];
    int                 sock_id[ MAX_CLIENT_THREAD * MAX_MASTER_THREAD];
    pthread_mutex_t     lock;
} CLIENT, *pCLIENT;

/*
   in base64.c
*/
char *x90c_base64_encode( char *str );
char *x90c_base64_decode( char *base64 );
int is_base64_encoded( char *str );

/*
   in hex.c
*/
char *hex_decode( char *string );

/* in parser.c */
#define MAX_URL                 2048

#define METHOD_GET          0x80
#define METHOD_POST         0x81
#define METHOD_HEAD         0x82
#define METHOD_UNKNOWN      0x83
#define COMMAND_QUIT        0x90

#define VERSION_1_0         0x100
#define VERSION_1_1         0x101
#define VERSION_UNKNOWN     0x102

#define CONTENT_TYPE_HTML                       0x080
#define CONTENT_TYPE_JPG                        0x081
#define CONTENT_TYPE_GIF                        0x082
#define CONTENT_TYPE_PNG                        0x083
#define CONTENT_TYPE_TIFF                       0x084
#define CONTENT_TYPE_ICO			0x085
#define CONTENT_TYPE_JS				0x086
#define CONTENT_TYPE_SWF			0x087
//#define CONTENT_TYPE_PERL                       0x085
// perl type is processed in main.c ( extension + html content type = perl type ) 
#define CONTENT_TYPE_APP_X_WWW_FORM_URLENCODED  0x088
#define CONTENT_TYPE_MP3			0X089

struct _METHOD
{
    int type;       // GET POST HEAD
    char *url;      // ��û URL
    int version;    // HTTP ����
} *pMETHOD;

struct _HOST
{
    char *ipaddr;   // ���� IP �ּ�
    int port;       // ���� ��Ʈ
} *pHOST;

struct _USERAGENT
{
    char *agent;    // ������
} *pUSERAGENT;

struct _REFERER
{
    char *url;      // ���� ������
} *pREFERER;

#define     MAX_POST_DATA_VAR_NAME  64
#define     MAX_POST_DATA_VAL       256 

struct _POST_DATA
{
    char var[ MAX_POST_DATA_VAR_NAME ];
    char val[ MAX_POST_DATA_VAL ];
} *pPOST_DATA;

#define     MAX_COOKIE_DATA_VAR_NAME    64
#define     MAX_COOKIE_DATA_VAL         256

struct _COOKIE_DATA
{
    char var[ MAX_COOKIE_DATA_VAR_NAME ];
    char val[ MAX_COOKIE_DATA_VAL ];
} *pCOOKIE_DATA;

struct _PARSED_MIME
{
    struct _METHOD      method;
    struct _HOST        host;
    char                lang[ 16 ];
    struct _USERAGENT   useragent;
    struct _REFERER     referer;
    struct _COOKIE_DATA cookie[ MAX_COOKIE ];
    struct _POST_DATA   post_data[ MAX_POST_VAR ];
    unsigned int        content_type;
    unsigned int        command1_1;
    char                ext[ 12 ];
} PARSED_MIME, *pPARSED_MIME;

int parse_data( struct _PARSED_MIME *pPMIME, char *string, int len, char *delim );
int parse_METHOD( char *request, struct _PARSED_MIME *pPMIME );
int parse_HOST( char *request, struct _PARSED_MIME *pPMIME );
int parse_LANG( char *request, struct _PARSED_MIME *pPMIME );
int checking_dir_traverse( char *url );
int parse_POST_data( char *request, struct _PARSED_MIME *pPMIME );
int parse_ContentType( char *request, struct _PARSED_MIME *pPMIME );
int asciiHex_decoding( char *request, struct _PARSED_MIME *pPMIME );
int base64_cookie_decoding( char *request, struct _PARSED_MIME *pPMIME );

struct _USER_ARGV
{
    char var_name[ 32 ];
    char var_value[ 128 ];
};

/* in main.c */
#define NO_FILE                 0xfffffff0

#define RBUF_SIZE               1310720 
#define MAX_POST_DATA           10240
#define MAX_RESPONSE            3000000 // 302400
#define MAX_URL_FILENAME        3042             // PATH ���� ����
#define MAX_HTML_FILE_DATA      300000
#define MAX_PERL_STDOUT         10240

#define MAX_USER_VARNAME        64          // GET var length
#define MAX_USER_VARVALUE       256         // GET var value

int init_httpd( int port, int max_user );
int init_logger( int level, char *filename );
void *server_thread( void *tid );
void *client_thread( void *sock_id );
int token_tags( char *MIME, int sock_id );
void no_signal();
void get_timestamp( char *times );
unsigned int read_file( char *filename, char *data );
int split_filename_url( struct _PARSED_MIME *pPMIME, char *filename );
int get_argv_url( struct _PARSED_MIME *pPMIME, struct _USER_ARGV *user_argv );
int configuration();
void *sigkill_handler( int signum );

/* in tcpip.c */
int init_server_thread( struct sockaddr_in *pserv_sock, 
                        int *psock_id, int port, int max_user );
int init_sock( struct sockaddr_in *psock, int *psock_id, char *ipaddr, int port );
int close_sock( struct _CLIENT *pClient, int sock_id );
int sock_send( int sock_id, char *data, int len );
int sock_recv( int sock_id, char *data, int len );

/* in mod_perl.c */
#define MAX_PERL_CMD            (MAX_URL + 64)  // /usr/bin/perl �н� ����

int do_perl( char *filename, int argc, struct _USER_ARGV *argv, char *perl_stdout,
       struct _PARSED_MIME *pPMIME );

/* in logger.c */
int set_logformat( int level );
int write_log( char *logdata );

