/*

    base64.c

    Date: 13.12.2009 
    Ref : http://ko.wikipedia.org/wiki/%EB%B2%A0%EC%9D%B4%EC%8A%A464

*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

static char ascii[] = {
	"ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    "abcdefghijklmnopqrstuvwxyz"
    "0123456789+/\0"
};

char *x90c_base64_encode(char *str)
{
    int p = 0, i = 0, j = 0, k = 0;
    int base64_len = 0;
    int base64_size = 0;
    int str_len = 0;
    char *base64 = NULL;

    str_len = strlen(str);

    base64_size = str_len + ((double)str_len / (double)100) * 80;
    base64 = malloc(base64_size + 1);

    if(!base64)
    {
        return (char *)-1;
    }

    memset(base64, 0, base64_size + 1);

    /* Base64 Encoding */
    for(i = 0, j = 0; *(str + j) != '\x00'; i+=4, j+=3 ){
        *(base64 + i) = ascii[ *(str + j) >> 2 ];
        *(base64 + (i+1)) = ascii[ ( ((*(str + j) & 0x3) << 4) | 
				( *(str + (j+1)) >> 4 ) ) & 0x3f];

        if( *(str + (j+1)) != '\x00')
            *(base64 + (i+2)) = ascii[ ( ( *(str + (j+1)) << 2 ) |
				 ( *(str + (j+2)) >> 6 ) ) & 0x3f ];
        if( *(str + (j+2)) != '\x00')
            *(base64 + (i+3)) = ascii[ ( *(str + (j+2)) & 0x3f ) ];
    }

    base64_len = strlen(base64);

    /* Padding for MIME */
    if( base64_len == 2 )
    {
        *(base64 + 3 ) = '=';
        *(base64 + 4 ) = '\x00';
    }

    p = 4 - (base64_len % 4);

    for(k = base64_len; k < (base64_len + p); k++)
    {

        *(base64 + k) = '=';
    }
    *(base64 + k) = '\x00';

    return(base64);
}

char *x90c_base64_decode(char *base64)
{
    int i = 0, j = 0, k = 0;
    int base64_len = strlen(base64);
    int buf_len = (base64_len / 3) + 32;
    char *buf = NULL;
    char b[base64_len];

    buf = malloc(buf_len);

    if(!buf){
        return((char *)-1);
    }

    memset(buf, 0, buf_len);

    for(i = 0; i < base64_len; i++)
    {
      for(j = 0; j < strlen(ascii); j++)
      {
          if(ascii[j] == *(base64+i))
            b[i] = (char) j;
          else if(*(base64+i) == '='){      // Ignore Padding.
              b[i] = '\x00';
              break;
          }
      }  
    }

    /* Base64 Decoding */ 
    for(i = 0, j = 0; b[i] != '\x00'; i+=3, j+=4)
    {
        *(buf + i) = ((b[j] & 0x3f) << 2) | ((b[j + 1] & 0x30) >> 4);
        *(buf + (i + 1)) = ((b[j + 1] & 0xf) << 4) | (b[j + 2] & 0x3c) >> 2;
        *(buf + (i + 2)) = ((b[j + 2] & 0x3) << 6) | (b[j + 3] & 0x3f);
    }
    
    *(buf + (i - 3) ) = '\x00';

    return(buf);

}

int is_base64_encoded( char *str )
{
    char blacklist[] = "`~!@#$%^&*()_-,.<>;:'\\\0";
    int i = 0, j = 0;;

    /* % 4 = 0 check! */
    if ( ( strlen( str ) % 4 ) != 0 )
    {
        return -1;
    }

    /* looking for blacklist matches */
    for( i = 0; i < strlen( str ); i++ )
    {
        for( j = 0; j < strlen( blacklist ); j++ ){
            if( *( str + i ) == blacklist[ j ] )
            {
                return -2;
            }       
        }
    }

    /* more :: detect (like  x90c and 1234 ) passed 
       almost base64 encoded string having '=' pad byte.
     */
    if( strchr( str, '=' ) == NULL )
    {
        return -3;
    } 

    return 0;
}

/*
int main(int argc, char *argv[])
{
    char *base64 = NULL;
    char *plain = NULL;

    plain = x90c_base64_decode("SGVsbG9Xb3JsZCE=");
    printf("%s\n", plain);
}

*/
