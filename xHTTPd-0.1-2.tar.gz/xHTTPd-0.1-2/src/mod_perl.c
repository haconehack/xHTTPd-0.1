/*
 * xHTTPd daemon.
 * Copyright(c) x90 all rights reserved.
 * Email: x90cx90c1@gmail.com
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <pthread.h>
#include <sys/socket.h>
#include <signal.h>

#include "main.h"

#define PERL_PATH   "/usr/bin/perl"

struct _PERL_VARS {
    char var[ MAX_COOKIE_DATA_VAR_NAME ];
    char val[ MAX_COOKIE_DATA_VAL ];
} *pPERL_VARS;

/*
 * �� ��ũ��Ʈ ����, ����
*/
int
do_perl( char *filename, int argc, struct _USER_ARGV *argv, char *perl_stdout,
      struct _PARSED_MIME *pPMIME )
{
    int i = 0, j = 0, k = 0;
    FILE *fp_pipe = NULL;
    char cmd[ MAX_PERL_CMD ];
    char argvs [ MAX_URL ];
    int perl_bytes = 0;
    int res = 0;
    struct _PERL_VARS pvars[ MAX_COOKIE ];
    int pvars_i = 0;

    memset( ( void * ) pvars, 0, sizeof( pvars ) );
    memset( argvs, 0, sizeof( argvs ) );
    memset( cmd, 0, sizeof( cmd ) );

    /* Method GET Variables */
    for( i = 0; i < argc; i++ )
    {
      /*printf("do_perl:: VAR[%d] -%s:%s-\n", i + 1, 
                ( argv + i )->var_name,
                ( argv + i )->var_value );*/

        sprintf( pvars[i].var, ( argv + i )->var_name );
        sprintf( pvars[i].val, ( argv + i )->var_value );
    }

    pvars_i = i;

    /* Method POST Variables */
    for( i = 0; i < MAX_POST_VAR; i++ )
    {
        if( *pPMIME->post_data[i].var != '\x00' )
        {
            for( k = 0; k < MAX_COOKIE; k++ )
            {
                if( strncmp( pvars[k].var, pPMIME->post_data[i].var, 
                            strlen( pvars[k].var)) == 0 )
                {
                    sprintf(pvars[k].var, "%s\0", pPMIME->post_data[i].var );
                    sprintf(pvars[k].val, "%s\0", pPMIME->post_data[i].val );
                    break;
                }
                    sprintf(pvars[pvars_i].var, "%s\0", pPMIME->post_data[pvars_i].var);
                    sprintf(pvars[pvars_i].val, "%s\0", pPMIME->post_data[pvars_i].val);
                    pvars_i ++;
            }
        }
    }

    /* Method Cookie Variables */
    for( i = 0; i < MAX_COOKIE; i++ )
    {
    
        if( *pPMIME->cookie[i].var != '\x00' )
        {
            for( k = 0; k < MAX_COOKIE; k++ )
            {
                if( strncmp( pvars[k].var, pPMIME->cookie[i].var, 
                            strlen( pvars[k].var)) == 0 )
                {
                    sprintf(pvars[k].var, "%s\0", pPMIME->cookie[i].var );
                    sprintf(pvars[k].val, "%s\0", pPMIME->cookie[i].val );
                    break;
                }
                    sprintf(pvars[pvars_i].var, "%s\0", pPMIME->cookie[pvars_i].var );
                    sprintf(pvars[pvars_i].val, "%s\0", pPMIME->cookie[pvars_i].val );
                    pvars_i ++;
            }
        }
    }

    printf("[ Perl Vars:: Order by COOKIE->POST->GET ]\n");

    for( i = 0; i < MAX_COOKIE; i++ )
    {
        if( *pvars[i].var == '\x00' )
        {
            break;
        }
        printf("\t$_PERL_VAR [ %s ] = %s\n", pvars[i].var, pvars[i].val );
        sprintf( argvs, "%s %s=%s", argvs, pvars[i].var, pvars[i].val );
    }

    if( ( ( strlen( PERL_PATH ) + strlen( filename ) + strlen( argvs ) ) - 3 ) 
            >= MAX_PERL_CMD )
    {  
        fprintf( stderr, "do_perl:: PERL ���ɶ��� ���̰� %d ���� ��ϴ�!\n", 
                MAX_PERL_CMD );
        res = -1;
        goto out;
    }

    sprintf( cmd, "%s %s %s\0", PERL_PATH, filename, argvs );
    printf("do_perl:: cmd = %s\n", cmd );

    // FIX: need some shell metacharacter filter ( ^ ; | & .. ) Security
    if(strstr(cmd, "^") || strstr(cmd, ";") || strstr(cmd, "|") || strstr(cmd, "&"))
    {
        fprintf(stderr, "do_perl:: popen �� ��Ÿ ĳ���� RCE �õ� Ž���Ǿ����ϴ�!\n");
        res = -2; 
        goto out;
    }
 
    if( ( fp_pipe = popen( cmd, "r" ) ) == NULL )
    {
        fprintf( stderr, "do_perl:: popen ���� !\n" );
        res = -3;
        goto out;
    }

    while( !feof( fp_pipe ) )
    {
        if( perl_bytes >= MAX_PERL_STDOUT - 1 )
        {
            fprintf( stderr, "do_perl:: perl_bytes �� %d ���� ��ϴ�!\n", MAX_PERL_STDOUT );
            res = -4;
            break;
        }

        *( perl_stdout + perl_bytes ) = fgetc( fp_pipe );
        perl_bytes ++;
    }
   
out:
    if( fp_pipe )
    {
        pclose( fp_pipe );
    }

    if( res < 0 )
    {
        return res;
    }
//  *( perl_stdout + perl_bytes ) = '\x00';

    return perl_bytes - 1;
}

